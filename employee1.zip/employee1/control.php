<?php

include_once('model.php');

    class control extends Model
    {
        function __construct()
        {
            model::__construct();
            
            $Path=$_SERVER['PATH_INFO']; 
            switch($Path)
            {
                case '/404';
                include_once('404.php');
                break;

                case '/Add_cat';
                if(isset($_REQUEST['submit']))
                {
                    $cat_name=$_REQUEST['cat_name'];
            

                    date_default_timezone_set('asia/calcutta');
                    $created_dt=date('Y-m-d H:i:s');
                    $updated_dt=date('Y-m-d H:i:s');

                    $arr=array("cat_name"=>$cat_name, "created_dt"=>$created_dt,"updated_dt"=>$updated_dt);
                    $res=$this->insert('category',$arr);
                    if($res)
                    {
                        echo "
                        <script>
                        alert('Registered Success');
                        window.location='index';
                        </script>
                        ";
                    }
                    else
                    {
                        echo "not success";
                    }
                }

                include_once('Add_cat.php');
                break;


                case '/Add_loc';
                if(isset($_REQUEST['submit']))
                {
                    $name=$_REQUEST['name'];
            

                    date_default_timezone_set('asia/calcutta');
                    $created_dt=date('Y-m-d H:i:s');
                    $updated_dt=date('Y-m-d H:i:s');

                    $arr=array("name"=>$name, "created_dt"=>$created_dt,"updated_dt"=>$updated_dt);
                    $res=$this->insert('location',$arr);
                    if($res)
                    {
                        echo "
                        <script>
                        alert('Registered Success');
                        window.location='index';
                        </script>
                        ";
                    }
                    else
                    {
                        echo "not success";
                    }
                }
                
                include_once('Add_loc.php');
                break;
                include_once('Add_loc.php');
                break;

                case '/Admin';
                include_once('Admin.php');
                break;


                case '/index';
                include_once('index.php');
                break;

                case '/Mng_Adv';    
                $car_adv_arr = $this->select('car_adv');
                include_once('Mng_adv.php');
                break;

                case '/Mng_cat';
                $category_arr = $this->select('category');
                include_once('Mng_cat.php');
                break;

                case '/Mng_contact';
                $contact_arr = $this->select('contact');
                include_once('Mng_contact.php');
                break;


                case '/Mng_loc';
                $location_arr=$this->select('location');
                include_once('Mng_loc.php');
                break;

                case '/Mng_user';
                $user_arr = $this->select('user');
                include_once('Mng_user.php');
                break;
 
                case '/signin';
                include_once('signin.php');
                break;


                case '/signup';
                include_once('signup.php');
                break;

                default :
                echo "Page not found";
            
            }
        }
    }
    $obj=new control;
?>