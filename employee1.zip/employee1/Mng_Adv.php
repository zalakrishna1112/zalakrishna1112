<!DOCTYPE html>
<html lang="en">

<?php
include_once('header.php');
?>
            <!-- Navbar End -->


            <!-- Table Start -->
            
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
            
                    <div class="col-12">
                        <div class="bg-secondary rounded h-100 p-4">
                            <h6 class="mb-4">Advertisement</h6>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            
                                            <th>Adv ID</th>
                                            <th>Category ID</th>
                                            <th>Location ID</th>
                                            <th>Owner Name</th>
                                            <th>Car Name</th>
                                            <th>Vehicle Number</th>
                                            <th>Mobile No.</th>
                                            <th>Adress</th>
                                            <th>Deposite</th>
                                            <th>Driver</th>
                                            <th>Charge</th>
                                            <th>Terms & Condition</th>
                                            <th>Created_date</th>
                                            <th>Updated_date</th>
                                            <th>action</th>
        
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php

                                                if(!empty($car_adv_arr))
                                                {
                                                    foreach($car_adv_arr as $data)
                                                {
                                     ?>
                                    <tr class="odd gradeX">
                                            <td><?php echo $data->adv_id;?></td>
                                            <td><?php echo $data->category_id;?></td>
                                            <td><?php echo $data->location_id;?></td>
                                            <td><?php echo $data->owener_name;?></td>
                                            <td><?php echo $data->car_name;?></td>
                                            <td><?php echo $data->vehical_number;?></td>
                                            <td><?php echo $data->mobile;?></td>
                                            <td><?php echo $data->address;?></td>
                                            <td><?php echo $data->deposite;?></td>
                                            <td><?php echo $data->driver;?></td>
                                            <td><?php echo $data->charge;?></td>
                                            <td><?php echo $data->terms_condition;?></td>
                                            <td><?php echo $data->crated_dt;?></td>
                                            <td><?php echo $data->updated_dt;?></td>
                                            <td>
                                                <a href="#" class="btn btn-primary">Edit</a>
                                                <a href="#" class="btn btn-danger">Delete</a>
                                                <a href="#" class="btn btn-success"><?php echo $data->status;?></a>
                                                </td>
                                                </tr>
                                                <?php
                                            }
                                        }
                                        ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    

            <!-- Table End -->


            <!-- Footer Start -->
            <?php
            include_once('Footer.php');
            ?>
            <!-- Footer End -->
        </div>
        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/chart/chart.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>