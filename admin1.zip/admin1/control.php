<?php
include_once('model.php');

    class control extends model 
    {
        function __construct()
        {
            session_start();
            model::__construct();


            $Path=$_SERVER['PATH_INFO']; 
            switch($Path)
            {
/*=======================================admin==============================*/
                case '/admin1':
                if(isset($_REQUEST['submit']))
            {
                $username=$_REQUEST['username'];
                $password=md5($_REQUEST['password']); 
                
                $arr=array("username"=>$username,"password"=>$password);
                
                $res=$this->select_where('admin',$arr); // func call  and cond check 
                $chk=$res->num_rows; // check res by rows that cond true or not
            
                if($chk==1) // 1 means true / and 0 means false
                {
                    $fetch=$res->fetch_object(); // data fetch after function call
                    // session create 
                    $_SESSION['admin_id']=$fetch->admin_id;
                    $_SESSION['name']=$fetch->name;
                   $_SESSION['username']=$fetch->username;

                    
                    
                    echo "
                    <script>
                    alert('Login Success');
                    window.location='dashboard';
                    </script>
                    ";
                }
                else
                {
                    echo "done";
                }
            }
            include_once('index.php');
            break;
/*=============================admin logout==========================================*/         
            
            case '/adminlogout':
            unset($_SESSION['admin_id']);
            unset($_SESSION['name']);
            unset($_SESSION['username']);
            echo "
                    <script>
                    alert('Logout Success');
                    window.location='admin';
                    </script>
                    ";
            break;

                case '/404':
                include_once('404.php');
                break;

                case '/Add_cat':
                if(isset($_REQUEST['submit']))
                {
                    $cat_name=$_REQUEST['cat_name'];
                    date_default_timezone_set('asia/calcutta');
                    $created_dt=date('Y-m-d H:i:s');
                    $updated_dt=date('Y-m-d H:i:s');

                    $arr=array("cat_name"=>$cat_name, "created_dt"=>$created_dt,"updated_dt"=>$updated_dt);
                    $res=$this->insert('category',$arr);
                    if($res)
                    {
                        echo "
                        <script>
                        alert('Registered Success');
                        window.location='Add_cat';
                        </script>
                        ";
                    }
                    else
                    {
                        echo "not success";
                    }
                }
                include_once('Add_cat.php');
                break;

                case '/mng_booking':
                $booking_arr = $this->select('booking');
                include_once('mng_booking.php');
                break;

                case '/Add_employee':
                if(isset($_REQUEST['submit']))
                {

                    $name=$_REQUEST['name'];
                    $email=$_REQUEST['email'];
                    $mobile=$_REQUEST['mobile'];
                    $username=$_REQUEST['username'];
                    $password=$_REQUEST['password'];
            

                    date_default_timezone_set('asia/calcutta');
                    $created_dt=date('Y-m-d H:i:s');
                    $updated_dt=date('Y-m-d H:i:s');

                    $arr=array("name"=>$name,"email"=>$email,"mobile"=>$mobile,"username"=>$username,
                        "password"=>$password, "created_dt"=>$created_dt,"updated_dt"=>$updated_dt);
                    $res=$this->insert('employee',$arr);
                    if($res)
                    {
                        echo "  
                        <script>
                        alert('Registered Success');
                        window.location='Add_employee';
                        </script>
                        ";
                    }
                    else
                    {
                        echo "not success";
                    }
                }
                
                include_once('Add_employee.php');
                break;

                case '/Add_loc':
                if(isset($_REQUEST['submit']))
                {
                    $name=$_REQUEST['name'];
            

                    date_default_timezone_set('asia/calcutta');
                    $created_dt=date('Y-m-d H:i:s');
                    $updated_dt=date('Y-m-d H:i:s');

                    $arr=array("name"=>$name, "created_dt"=>$created_dt,"updated_dt"=>$updated_dt);
                    $res=$this->insert('location',$arr);
                    if($res)
                    {
                        echo "
                        <script>
                        alert('Registered Success');
                        window.location='Add_loc';
                        </script>
                        ";
                    }
                    else
                    {
                        echo "not success";
                    }
                }
                
                include_once('Add_loc.php');
                break;

                case '/footer':
                include_once('footer.php');
                break;

                case '/header':
                include_once('header.php');
                break;

                case '/dashboard':
                include_once('dashboard.php');
                break;

        
                case '/Mng_Adv':
                $adv_arr = $this->select('car_adv');
                include_once('Mng_adv.php');
                break;

                case '/Mng_cat':
                $category_arr = $this->select('category');
                include_once('Mng_cat.php');
                break;

                case '/Mng_contact':
                $contact_arr=$this->select('contact');
                include_once('Mng_contact.php');
                break;

                case '/Mng_employee':
                $employee_arr = $this->select('employee');
                include_once('Mng_employee.php');
                break;

                case '/Mng_loc':
                $location_arr = $this->select('location');
                include_once('Mng_loc.php');
                break;

                case '/Mng_user':
                $user_arr = $this->select('user');
                include_once('Mng_user.php');
                break;
 
                case '/sign-in':
                include_once('sign-in.php');
                break;


                case '/signup':
                include_once('signup.php');
                break;

/*=========================================delete==============================*/
                case '/delete':
                if(isset($_REQUEST['del_contact_id']))
                {
                $contact_id=$_REQUEST['del_contact_id'];
                $where=array("contact_id"=>$contact_id);
                
                $res=$this->delete_where('contact',$where);
                if($res)
                {
                    echo "
                    <script>
                    alert('Delete Success');
                    window.location='Mng_contact';
                    </script>
                    ";
                }
                }

            
            if(isset($_REQUEST['del_user_id']))
            {
                $user_id=$_REQUEST['del_user_id'];
                $where=array("user_id"=>$user_id);
                
                $res=$this->delete_where('user',$where);
                if($res)
                {
                   echo "
                    <script>
                    alert('Delete Success');
                    window.location='Mng_user';
                    </script>
                    ";                
                }
            }


            if(isset($_REQUEST['del_category_id']))
            {
                $category_id=$_REQUEST['del_category_id'];
                $where=array("category_id"=>$category_id);
                
                $res=$this->delete_where('category',$where);
                if($res)
                {
                   echo "
                    <script>
                    alert('Delete Success');
                    window.location='Mng_cat';
                    </script>
                    ";                
                }
            }

            if(isset($_REQUEST['del_adv_id']))
            {
                $adv_id =$_REQUEST['del_adv_id'];
                $where=array("adv_id"=>$adv_id);
                
                $res=$this->delete_where('car_adv',$where);
                if($res)
                {
                   echo "
                   <script>
                   alert('Delete Success');
                   window.location='Mng_Adv';
                   </script>
                   ";

                }
            }


            if(isset($_REQUEST['del_employee_id']))
            {
                $employee_id =$_REQUEST['del_employee_id'];
                $where=array("employee_id"=>$employee_id);
                
                $res=$this->delete_where('employee',$where);
                if($res)
                {
                   echo "
                   <script>
                   alert('Delete Success');
                   window.location='Mng_employee';
                   </script>
                   ";

                }
            }

            break;

 /*================================satus==============================*/               

            case '/status':
            if(isset($_REQUEST['status_employee_id']))
            {
                $employee_id=$_REQUEST['status_employee_id'];
                $where=array("employee_id"=>$employee_id);
                
                $res=$this->select_where('employee',$where);
                $fetch=$res->fetch_object();
                
                if($fetch->status=="block")
                {
                    $arr=array("status"=>"unblock");
                    $res=$this->update('employee',$arr,$where);
                    if($res)
                    {
                        echo "
                        <script>
                        alert('user Unblock Success');
                        window.location='Mng_employee';
                        </script>
                        ";
                    }
                }
                else
                {
                    $arr=array("status"=>"block");
                    $res=$this->update('employee',$arr,$where);
                    if($res)
                    {
                        echo "
                        <script>
                        alert('user Block Success');
                        window.location='Mng_employee';
                        </script>
                        ";
                    }
                }
            }



            if(isset($_REQUEST['status_user_id']))
            {
                $user_id=$_REQUEST['status_user_id'];
                $where=array("user_id"=>$user_id);
                
                $res=$this->select_where('user',$where);
                $fetch=$res->fetch_object();
                
                if($fetch->status=="block")
                {
                    $arr=array("status"=>"unblock");
                    $res=$this->update('user',$arr,$where);
                    if($res)
                    {
                        echo "
                        <script>
                        alert('user Unblock Success');
                        window.location='Mng_user';
                        </script>
                        ";
                    }
                }
                else
                {
                    $arr=array("status"=>"block");
                    $res=$this->update('user',$arr,$where);
                    if($res)
                    {
                        echo "
                        <script>
                        alert('user Block Success');
                        window.location='Mng_user';
                        </script>
                        ";
                    }
                }
            }


            if(isset($_REQUEST['status_category_id']))
            {
                $category_id=$_REQUEST['status_category_id'];
                $where=array("category_id"=>$category_id);
                
                $res=$this->select_where('category',$where);
                $fetch=$res->fetch_object();
                
                if($fetch->status=="block")
                {
                    $arr=array("status"=>"unblock");
                    $res=$this->update('category',$arr,$where);
                    if($res)
                    {
                        echo "
                        <script>
                        alert('user Unblock Success');
                        window.location='Mng_cat';
                        </script>
                        ";
                    }
                }
                else
                {
                    $arr=array("status"=>"block");
                    $res=$this->update('category',$arr,$where);
                    if($res)
                    {
                        echo "
                        <script>
                        alert('user Block Success');
                        window.location='Mng_cat';
                        </script>
                        ";
                    }
                }
            }
            
            
            break;


               default :
                echo "Page not found";
                break;
            }
        }
    }


    $obj=new control;
?>