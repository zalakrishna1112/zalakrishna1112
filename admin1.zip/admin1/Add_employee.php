<?php
include_once('header.php');
?>
            <!-- Navbar End -->


            <!-- Form Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-sm-12 ">
                        <div class="bg-secondary rounded h-100 p-4">
                            <h6 class="mb-4">Employee</h6>
                            <form action="" method="post">


                                <div class="mb-3">
                                    <label for="exampleInputName" class="form-label">Employee Name</label>
                                    <input type="name" name="name" class="form-control" id="exampleInputName"
                                        aria-describedby="emailHelp">
                                    </div>


                                 <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Email address</label>
                                    <input type="email" name="email" class="form-control" id="exampleInputEmail1"
                                        aria-describedby="emailHelp">
                                </div>


                                <div class="mb-3">
                                    <label for="exampleInputMobile" class="form-label">Mobile Number</label>
                                    <input type="mobile" name="mobile" class="form-control" id="exampleInputMobile "
                                        aria-describedby="emailHelp">
                                </div>

                                <div class="mb-3">
                                    <label for="exampleInputUsername" class="form-label">User name</label>
                                    <input type="username" name="username" class="form-control" id="exampleInputUsername"
                                        aria-describedby="emailHelp">
                                 </div>

                                
                                <div class="mb-3">
                                    <label for="exampleInputPassword1" class="form-label">Password</label>
                                    <input type="password" name="password" class="form-control" id="exampleInputPassword1">
                                </div>

                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                    <label class="form-check-label"name="checkbox" for="exampleCheck1">Check me out</label>
                                </div>
                                <button type="submit" name ="submit" class="btn btn-primary">Submit</button>
                            </form>
                        </div>
                    </div>
            <!-- Form End -->


            <!-- Footer Start -->
            <?php
            include_once('Footer.php');
            ?>
            <!-- Footer End -->
        </div>
        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/chart/chart.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>